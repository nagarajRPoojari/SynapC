#ifndef METRIC_H
#define METRIC_H

double accuracy(NdArray predicted,NdArray actual);



#endif

