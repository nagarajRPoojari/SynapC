#ifndef LOSS_H
#define LOSS_H


double cross_entropy(NdArray predicted,NdArray actual);


#endif

